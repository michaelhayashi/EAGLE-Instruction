Dimensions: 1.500 in. wide x 1.450 in. tall
Area: 2.175 in.^2
Copies: 1 (one)

Contact:
Michael Hayashi
Purdue IEEE Student Organization
Email: mhayashi@purdue.edu
Phone: (309) 370-4274